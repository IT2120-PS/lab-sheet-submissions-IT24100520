setwd("C:/Users/yuuta/OneDrive/Desktop/IT24100520")

# Enter observed data
snacks <- c(120, 95, 85, 100)

# Label the categories for clarity
names(snacks) <- c("A", "B", "C", "D")

# Display the data
print("Observed snack choices:")
print(snacks)

# Perform Chi-Square Goodness-of-Fit test
# Assuming all snacks are equally likely (equal probability = 1/4 each)
result <- chisq.test(snacks, p = rep(1/4, 4))

# Show full test results
print(result)

# Extract specific output values
cat("Chi-square statistic:", result$statistic)
cat("Degrees of freedom:", result$parameter)
cat("p-value:", result$p.value, "\n")

# Interpretation
if (result$p.value > 0.05) {
  cat("Conclusion: Fail to reject H0 — Snack types are equally preferred.")
} else {
  cat("Conclusion: Reject H0 — Some snack types are preferred more than others.")
}

#Visualization
barplot(snacks,
        main = "Snack Choices from Vending Machine",
        xlab = "Snack Type",
        ylab = "Number of Customers",
        col = c("skyblue", "orange", "green", "pink"))
